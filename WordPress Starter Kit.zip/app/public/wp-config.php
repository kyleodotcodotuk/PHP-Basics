<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

/**
 * Place License Keys that are owned by Resknow in
 * license-keys.php, when transferring a site away from
 * us, clients will need to purchase keys for these services
 */
if ( file_exists(__DIR__ . '/.license-keys.php') ) {
	require_once __DIR__ . '/.license-keys.php';
}

define( 'WPCF7_AUTOP', false );

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'xmhL9toyzhclvPiB34hRRd0dgF/RvSwVNg6vbtZUCI9pI+NOvYLj3l5iwYKqnSbowXZun5LkHyyv0JLulkXPnQ==');
define('SECURE_AUTH_KEY',  'DWsIZfHtmWjOMQiletWcCd2bMLcB0BX3qFFiBFyeerxYv8QbU8G+ixOcJc4EqyQ9qYlqL8p3xpZYAMYABQXeRA==');
define('LOGGED_IN_KEY',    'uKRWgB2S8x1vI+oRqLYUgfC+O+TD5DNdovBOxtnVc7ygjXkk+W9G2dHK7GfnTKzA0BGxwzUneJJsm7aqH1uT+w==');
define('NONCE_KEY',        'IkQrM3yZJBCTYFqnUFAZKmvg5vNRK+cDgFPpsyQuBytv3oB6txzDcBDQN5cvowLJXBZtu4Yn3bGLE+Meid2XuQ==');
define('AUTH_SALT',        '/l1pjvJTA+APAqiteESmfoze4ovetfhNTyAI5yW02uW8aLIRohBEew3vXt6zpSzEg0tf5YB05iyFtYxcOejkUA==');
define('SECURE_AUTH_SALT', 'mTl3EFRuAZRvjUM7F3Tds+gI+Y97pyNvikRPaCM85tw0Om0sSmfJJ8+Rk7MvSRSrVXVtCp+8mFbzj1x0Qhz9DQ==');
define('LOGGED_IN_SALT',   '0D/Q14JaH+z3cD4VasifJK42i+P9hYkewyf6i5Z64EdB2cboVMFM83BidPUzIJSoly+tIVa6gYPGMcXuuehCsg==');
define('NONCE_SALT',       'a7tIY+LuUBxzz6oYKtgW9WiDOQ/+4kcJsMhB5bUm95BhqfT2pq983FO7x5/6EquzrC84DrzzjZNZsoyl7dmxtA==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
